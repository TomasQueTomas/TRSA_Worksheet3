#include "tripod_description/base_to_sensor.hpp"

using namespace TRIPOD_DESCRIPTION;

Base_to_sensor::Base_to_sensor(){
	sub = nh.subscribe("/tripod/height",10,&Base_to_sensor::height_clbk,this);
}
void Base_to_sensor::run(){
	ros::spin();
}
void Base_to_sensor::height_clbk(const std_msgs::Float32& msg){
	transform.setOrigin( tf::Vector3(0.0, 0.0, msg.data) );
	ROS_INFO("O float recebido foi: %.2f",msg.data);
	q.setRPY(0, 0, 0.0);
	transform.setRotation(q);
	br.sendTransform(tf::StampedTransform(transform, ros::Time::now(), "base_footprint", "sensor_frame"));
}