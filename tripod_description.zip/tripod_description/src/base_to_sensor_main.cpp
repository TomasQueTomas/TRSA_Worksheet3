#include "tripod_description/base_to_sensor.hpp"


int main( int argc, char** argv )
{
    ros::init( argc, argv, "base_to_sensor" );

    TRIPOD_DESCRIPTION::Base_to_sensor broadcast;

    broadcast.run();

    return 0;
}
