
#ifndef BASE_TO_SENSOR_HPP
#define BASE_TO_SENSOR_HPP

#include "ros/ros.h"
#include <tf/transform_broadcaster.h>
#include "std_msgs/Float32.h"

namespace TRIPOD_DESCRIPTION
{
    class Base_to_sensor{
      public:
      
        Base_to_sensor();
        virtual ~Base_to_sensor(){};
        void run();
         
      private:
      ros::Subscriber sub; 
      ros::NodeHandle nh;
      void height_clbk(const std_msgs::Float32&);
      tf::Transform transform;
      tf::Quaternion q;
      tf::TransformBroadcaster br;
    };
}
#endif